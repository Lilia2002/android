package com.example.sameproject

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val arrayList = arrayListOf(
            UserModel("Valod","Poxosyan",R.drawable.b),
            UserModel("Gexam","Poxosyan",R.drawable.c),
            UserModel("VArd","KVGVKH",R.drawable.d),
            UserModel("AJnx","Poxosyan",R.drawable.f),
            UserModel("KHG","KHVK",R.drawable.g),
            UserModel("BJC","Poxosyan",R.drawable.c),
            UserModel("LJHLJ","Poxosyan",R.drawable.b),
        )
        val recView = findViewById<RecyclerView>(R.id.my_recc)
        recView.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
        val adapter = MainActivityAdapter(this,arrayList)
        recView.adapter = adapter

    }
}