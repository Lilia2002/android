package com.example.sameproject

data class UserModel(
    var firstName:String,
    var lastNume:String,
    var photoUri :Int
)
