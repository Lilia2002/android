package com.example.sameproject

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

class MainActivityAdapter(val context:Context,val myModelList:ArrayList<UserModel>):RecyclerView.Adapter<MainActivityAdapter.MainViewHolder>(){

    class MainViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val tvFirstName = itemView.findViewById<TextView>(R.id.tv_first_name)
        val tvLastName = itemView.findViewById<TextView>(R.id.tv_last_name)
        val imageView = itemView.findViewById<ImageView>(R.id.imageView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_rec, parent, false)
        return MainViewHolder(view)
    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        holder.imageView.setImageResource(myModelList[position].photoUri)
        holder.tvFirstName.text = myModelList[position].firstName
        holder.tvLastName.text = myModelList[position].lastNume
        holder.imageView.setOnClickListener {
            Toast.makeText(context, myModelList[position].firstName, Toast.LENGTH_SHORT).show()
        }
    }

    override fun getItemCount(): Int {
      return myModelList.size
    }
}