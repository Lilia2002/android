package com.example.phonecontact

data class User( var firstName:String, var lastName:String, var phoneNumber:String,val imageId:Int) {
}