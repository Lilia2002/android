package com.example.phonecontact

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.FieldPosition

class MainActivity : AppCompatActivity() {
private lateinit var rv: RecyclerView
private lateinit var layoutManager: LinearLayoutManager
private lateinit var adapter: RecyclerViewAdapter


private lateinit var contacts:ArrayList<User>
override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    initContact()
    initRecyclerView()

        
    }


private fun initRecyclerView(){
    rv= findViewById(R.id.my_rec_view)
    layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL,false)
    adapter= RecyclerViewAdapter(contacts)
    rv.layoutManager=layoutManager
    rv.adapter=adapter
    rv.addItemDecoration(DividerItemDecoration(rv.context,layoutManager.orientation))

}
private fun initContact(){
    contacts= ArrayList()
    contacts.add(User("Hasmik","Manukyan","077678900",R.drawable.a))
    contacts.add(User("Ruzan","Hakobyan","077878900",R.drawable.b))
    contacts.add(User("Hasmik","Manukyan","077678900",R.drawable.c))
    contacts.add(User("Lilit","Bldeyan","077678900",R.drawable.a))
    contacts.add(User("Armine","Sahakyan","077678900",R.drawable.b))
    contacts.add(User("Satenik","Sahakyan","099678900",R.drawable.d))
    contacts.add(User("Srbuhi","Manukyan","094678900",R.drawable.a))
    contacts.add(User("Hasmik","Manukyan","077678900",R.drawable.a))
    contacts.add(User("Ruzan","Hakobyan","077878900",R.drawable.b))
    contacts.add(User("Hasmik","Manukyan","077678900",R.drawable.c))
}


}
