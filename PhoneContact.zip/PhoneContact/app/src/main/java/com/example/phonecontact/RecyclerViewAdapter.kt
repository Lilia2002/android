package com.example.phonecontact

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class RecyclerViewAdapter(var contacts:ArrayList<User>): RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder = ViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.recycleritemuser, parent, false)

    )


    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvName.text = contacts[position].firstName
        holder.tvPhoneNumber.text = contacts[position].phoneNumber
        holder.tvLastName.text = contacts[position].lastName
        val tempUserModel = contacts[position]
        holder.bind(tempUserModel)
    }

    override fun getItemCount(): Int {
        return contacts.size
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvName: TextView = itemView.findViewById(R.id.firstName)
        val tvLastName: TextView = itemView.findViewById(R.id.lastName)
        val tvPhoneNumber: TextView = itemView.findViewById(R.id.phoneNumber)
        val imgAvatar = itemView.findViewById<ImageView>(R.id.profilePictureImageView)

        fun bind(user: User) {
            imgAvatar.setImageResource(user.imageId)


        }


    }
    interface OnClickListener{
       fun setOnClickListener(pos:Int)
       fun setOnLongClickListener(pos:Int)
    }

}


