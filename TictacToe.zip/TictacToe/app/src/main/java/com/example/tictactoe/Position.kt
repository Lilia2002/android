package com.example.tictactoe

data class Position(val row: Int, val column: Int)