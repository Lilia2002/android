package com.example.sqlitedatabase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.mysqlitedatabase.R
import kotlinx.android.synthetic.main.activity_add.*

class AddActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add)

        supportActionBar?.title = "Add student"

        val dbHandler = DatabaseHandler(this)

        btn_save.setOnClickListener {
            val student = Student(null, et_name.text.toString(), et_email.text.toString())

            if (dbHandler.addStudent(student) != 0.toLong()) {
                Toast.makeText(this, "it has been successfully added", Toast.LENGTH_LONG).show()
                finish()
            }else {
                Toast.makeText(this, "Data could not be added ", Toast.LENGTH_LONG).show()
            }
        }
    }
}