package com.example.sqlitedatabase

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.mysqlitedatabase.R
import kotlinx.android.synthetic.main.activity_edit.*

class EditActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit)

        val dbHandler = DatabaseHandler(this)


        val student = intent.getParcelableExtra<Student>("student")

        supportActionBar?.title ="Change data ${student?.name}"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        et_name.setText(student?.name)
        et_email.setText(student?.email)

        btn_save.setOnClickListener {

            student?.name = et_name.text.toString()
            student?.email = et_email.text.toString()

            student?.let {

                if (dbHandler.updateStudent(it) != 0) {
                    Toast.makeText(this, "It has been changed successfully", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "It has been failed to change", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return super.onSupportNavigateUp()
    }
}