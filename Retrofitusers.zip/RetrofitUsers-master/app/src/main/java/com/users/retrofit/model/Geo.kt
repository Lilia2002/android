package com.users.retrofit.model

data class Geo(
    val lat: String,
    val lng: String
)