package com.users.retrofit.model

class MyPhotos : ArrayList<MyPhotosItem>()