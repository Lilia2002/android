package com.example.applebox

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.isVisible
import kotlinx.coroutines.*

class MainActivity2 : AppCompatActivity() {
    private lateinit var quantityText: TextView
    private lateinit var resetButton: Button
    private lateinit var context: Context
    private lateinit var progressBar:ProgressBar
    private lateinit var  btnAdd: Button
    private lateinit var btnTake: Button
    private var init = 0
    private var max = 0
    private var quantity = 0
    private var resetVisible = false
        get() = quantity==0 || quantity==max
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        init = this.intent.getIntExtra("init", 0)
        max = this.intent.getIntExtra("max",0)
        quantity = init
        context = this

        btnAdd=findViewById(R.id.add)
         btnTake=findViewById(R.id.take)
        progressBar = findViewById(R.id.progress_horizontal)
        resetButton = findViewById(R.id.reset)
        quantityText = findViewById(R.id.quantity)

        resetButton.isVisible = resetVisible
        quantityText.text = quantity.toString()


        resetButton.setOnClickListener {
            quantity = init
            quantityText.text = quantity.toString()
            resetButton.isVisible = resetVisible
        }
    }


    fun changeQuantity(view: View){
        var mess = ""
        GlobalScope.launch(Dispatchers.IO){
            when (view) {
                findViewById<Button>(R.id.take) -> {
                    if (quantity > 0) {
                        updateProgressBar()

                        quantity--
                        mess = "An apple was token from box"
                    } else {
                        mess = "Box is empty"
                    }
                }
                findViewById<Button>(R.id.add) -> {
                    delay(1000)
                    if (quantity < max) {
                        quantity++
                        updateProgressBar()
                        mess = "An apple was added"
                    } else {
                        mess = "Box is full"
                    }
                }
            }
            withContext(Dispatchers.Main){
                Toast.makeText(context, mess,Toast.LENGTH_SHORT).show()
                quantityText.text = quantity.toString()
                resetButton.isVisible = resetVisible
            }

        }



    }
    suspend fun updateProgressBar(){
        withContext(Dispatchers.Main) {
            quantityText.text = "Preparing"
            btnTake.isEnabled = false
            btnAdd.isEnabled=false


        }
        delay(1000)
        for (p in 1..100) {
            delay(100)
            withContext(Dispatchers.Main) {
                quantityText.text = "$p% Downloaded..."
                progressBar.progress = p
            }
        }
        withContext(Dispatchers.Main) {
            quantityText.text = "Download Completed"
            btnTake.isEnabled = true
            btnAdd.isEnabled=true
        }
    }

}
